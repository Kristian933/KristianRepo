package pizzaCalories;

public enum FlourType {
    White,
    Wholegrain,
}
