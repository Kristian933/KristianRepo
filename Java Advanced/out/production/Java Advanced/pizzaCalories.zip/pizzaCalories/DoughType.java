package pizzaCalories;

public enum DoughType {
    Crispy,
    Chewy,
    Homemade,
}