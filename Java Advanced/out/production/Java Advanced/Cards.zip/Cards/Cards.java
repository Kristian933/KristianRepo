package Cards;

public enum Cards {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES,

}
