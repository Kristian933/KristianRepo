package telephony;

public interface Callable {
    public String call();
}
