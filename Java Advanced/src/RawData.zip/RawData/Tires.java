package RawData;

public class Tires {

    private double tirePressure;


    public Tires(double tirePressure) {
        this.tirePressure = tirePressure;
    }

    public double getTirePressure() {
        return tirePressure;
    }
}
