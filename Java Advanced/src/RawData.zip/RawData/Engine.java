package RawData;

public class Engine {

    private Integer engine;

    public void setEngine(Integer engine) {
        this.engine = engine;
    }

    public int getEngine() {
        return engine;
    }

    public Engine(Integer engine) {
        this.engine = engine;
    }
}
