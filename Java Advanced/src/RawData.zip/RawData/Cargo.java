package RawData;

public class Cargo {

    private String cargo;

    public Cargo(String cargo) {
        this.cargo = cargo;
    }

    public String getCargo() {
        return cargo;
    }

}
