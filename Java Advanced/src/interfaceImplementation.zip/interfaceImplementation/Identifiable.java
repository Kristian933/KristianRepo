package interfaceImplementation;

public interface Identifiable {
    public String getId();
}
