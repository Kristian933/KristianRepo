package interfaceImplementation;

public interface Birthable {
    public String getBirthDate();
}
